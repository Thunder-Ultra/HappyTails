import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

import { Button } from '../components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Label } from '../components/ui/label';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '../components/ui/dialog';

import { Plus, Edit, Trash2, Eye, Upload } from 'lucide-react';
import { toast } from 'sonner';

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle
} from '../components/ui/alert-dialog';

// Define Breeds per Pet Type
const PET_DATA = {
  Dog: [
    'Golden Retriever', 'Labrador', 'Bulldog', 'Beagle', 'Poodle',
    'German Shepherd', 'Husky', 'Pug', 'Mixed Breed', 'Other'
  ],
  Cat: [
    'Persian', 'Siamese', 'Maine Coon', 'Bengal', 'Ragdoll',
    'British Shorthair', 'Sphynx', 'Mixed Breed', 'Other'
  ],
  Bird: [
    'Parrot', 'Canary', 'Finch', 'Cockatiel', 'Lovebird', 'Other'
  ],
  Rabbit: [
    'Holland Lop', 'Netherland Dwarf', 'Lionhead', 'Dutch', 'Other'
  ],
  Other: ['Other']
};

export const AdoptablesPage = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const BASE_URL = import.meta.env.VITE_BASE_URL;

  const [myAdoptables, setMyAdoptables] = useState([]);
  const [requests, setRequests] = useState([]);

  // UI States
  const [addAdoptableOpen, setAddAdoptableOpen] = useState(false);
  const [editingAdoptable, setEditingAdoptable] = useState(null);
  const [deletingAdoptableId, setDeletingAdoptableId] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const [adoptableForm, setAdoptableForm] = useState({
    name: '',
    age: 1,
    weight: 0,
    height: 0,
    breed: '',
    type: 'Dog',
    vaccinated: false,
    address: '',
    description: '',
    images: [] // Changed to empty array for file objects
  });

  const [imagePreview, setImagePreview] = useState('');

  // Helper to get token
  const getToken = () => localStorage.getItem('token');

  useEffect(() => {
    if (user) {
      loadMyAdoptables();
      loadRequests();
    }
  }, [user]);

  // Helper to construct image URL (handles external links vs local uploads)
  const getImageUrl = (imagePath) => {
    if (!imagePath) return null;
    if (imagePath.startsWith('http')) return imagePath;
    // Assuming your backend serves uploads at /uploads/adoptables/ or similar
    // Adjust '/uploads/' based on your app.use('/uploads', ...) in express
    return `${BASE_URL}/uploads/adoptables/${imagePath}`;
  };

  // 1. Load from Backend
  const loadMyAdoptables = async () => {
    try {
      setIsLoading(true);
      const response = await fetch(`${BASE_URL}/adoptables/my`, {
        headers: {
          'Authorization': `Bearer ${getToken()}`
        }
      });

      if (!response.ok) throw new Error('Failed to fetch adoptables');

      const data = await response.json();
      setMyAdoptables(data);
    } catch (error) {
      console.error("Error loading adoptables:", error);
      toast.error("Could not load your adoptables.");
    } finally {
      setIsLoading(false);
    }
  };

  // 2. Load Requests
  const loadRequests = async () => {
    try {
      const response = await fetch(`${BASE_URL}/adoptables/adoption-requests`, {
        headers: {
          'Authorization': `Bearer ${getToken()}`
        }
      });

      if (!response.ok) throw new Error('Failed to fetch requests');

      const allRequests = await response.json();
      const myRequests = allRequests ? allRequests.filter(
        (r) => r.caretaker_id === user?.id && r.status === 'pending'
      ) : [];
      setRequests(myRequests);
    } catch (error) {
      console.error("Error loading requests:", error);
    }
  };

  // Handle File Input Change
  const handleFileChange = (e) => {
    const files = Array.from(e.target.files);
    if (files.length > 0) {
      // Store actual File objects for upload
      setAdoptableForm(prev => ({ ...prev, images: files }));

      // Create a local preview URL for the first image so the user sees what they picked
      const previewUrl = URL.createObjectURL(files[0]);
      setImagePreview(previewUrl);
    }
  };

  // 3. Add Logic (Updated for Multer/FormData)
  const handleAddAdoptable = async () => {
    if (!user) return;

    if (!adoptableForm.name || !adoptableForm.breed || !adoptableForm.address || !adoptableForm.description) {
      toast.error('Please fill in all required fields');
      return;
    }

    try {
      const formData = new FormData();

      // Append text fields
      formData.append('caretaker_id', user.id);
      formData.append('name', adoptableForm.name);
      formData.append('age', adoptableForm.age);
      formData.append('weight', adoptableForm.weight);
      formData.append('height', adoptableForm.height);
      formData.append('breed', adoptableForm.breed);
      formData.append('type', adoptableForm.type);
      formData.append('vaccinated', adoptableForm.vaccinated); // Sends "true"/"false"
      formData.append('address', adoptableForm.address);
      formData.append('description', adoptableForm.description);
      formData.append('status', 'available');

      // Append Images (File Objects)
      if (adoptableForm.images && adoptableForm.images.length > 0) {
        adoptableForm.images.forEach((file) => {
          if (file instanceof File) {
            formData.append('images', file);
          }
        });
      }

      const response = await fetch(`${BASE_URL}/adoptables`, {
        method: 'POST',
        headers: {
          // Content-Type must be undefined for FormData so browser sets boundary
          'Authorization': `Bearer ${getToken()}`
        },
        body: formData,
      });

      if (!response.ok) throw new Error('Failed to add adoptable');

      await loadMyAdoptables();
      setAddAdoptableOpen(false);
      resetForm();
      toast.success('Adoptable added successfully!');
    } catch (error) {
      toast.error('Error adding adoptable');
      console.error(error);
    }
  };

  // 4. Update Logic
  const handleUpdateAdoptable = async () => {
    if (!editingAdoptable) return;

    try {
      // Note: For now keeping update as JSON. If you want to support Image updates,
      // you need to convert this to FormData as well.
      const response = await fetch(`${BASE_URL}/adoptables/${editingAdoptable.id || editingAdoptable._id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${getToken()}`
        },
        body: JSON.stringify({ ...editingAdoptable, ...adoptableForm }),
      });

      if (!response.ok) throw new Error('Failed to update adoptable');

      await loadMyAdoptables();
      setEditingAdoptable(null);
      resetForm();
      setAddAdoptableOpen(false);
      toast.success('Adoptable updated successfully!');
    } catch (error) {
      toast.error('Error updating adoptable');
      console.error(error);
    }
  };

  // 5. Delete Logic
  const handleDeleteAdoptable = async (adoptableId) => {
    try {
      const response = await fetch(`${BASE_URL}/adoptables/${adoptableId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${getToken()}`
        }
      });

      if (!response.ok) throw new Error('Failed to delete adoptable');

      await loadMyAdoptables();
      setDeletingAdoptableId(null);
      toast.success('Adoptable removed from listings');
    } catch (error) {
      toast.error('Error deleting adoptable');
      console.error(error);
    }
  };

  const resetForm = () => {
    setAdoptableForm({
      name: '',
      age: 1,
      weight: 0,
      height: 0,
      breed: '',
      type: 'Dog',
      vaccinated: false,
      address: '',
      description: '',
      images: []
    });
    setImagePreview('');
  };

  const openEditDialog = (adoptable) => {
    setEditingAdoptable(adoptable);
    setAdoptableForm({
      name: adoptable.name,
      age: adoptable.age,
      weight: adoptable.weight,
      height: adoptable.height,
      breed: adoptable.breed,
      type: adoptable.type || 'Dog',
      vaccinated: adoptable.vaccinated === "Yes" || adoptable.vaccinated === true,
      address: adoptable.address,
      description: adoptable.description,
      images: [] // We don't load existing files into the file input, only URLs for display
    });

    // Handle preview for existing image
    const firstImage = adoptable.images && adoptable.images.length > 0 ? adoptable.images[0] : '';
    setImagePreview(getImageUrl(firstImage));

    setAddAdoptableOpen(true);
  };

  const handleFormChange = (e) => {
    const { name, value } = e.target;

    if (name === 'type') {
      setAdoptableForm(prev => ({
        ...prev,
        [name]: value,
        breed: ''
      }));
    } else {
      setAdoptableForm(prev => ({ ...prev, [name]: value }));
    }
  };

  const selectStyle = "flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50";

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl mb-2">My Adoptables</h1>
          <p className="text-gray-600">Manage adoptables you've listed for adoption</p>
        </div>
        {myAdoptables.length > 0 && (
          <Button onClick={() => { resetForm(); setAddAdoptableOpen(true); }}>
            <Plus className="h-4 w-4 mr-2" />
            Add New Adoptable
          </Button>
        )}
      </div>

      {requests.length > 0 && (
        <Card className="mb-8 bg-purple-50 border-purple-200">
          <CardHeader>
            <CardTitle>You have {requests.length} pending adoption request{requests.length > 1 ? 's' : ''}</CardTitle>
          </CardHeader>
          <CardContent>
            <Button onClick={() => navigate('/requests')}>View All Requests</Button>
          </CardContent>
        </Card>
      )}

      {isLoading ? (
        <div className="text-center py-20">Loading adoptables...</div>
      ) : myAdoptables.length === 0 ? (
        <div className="text-center py-20">
          <p className="text-gray-500 text-lg mb-4">You haven't listed any adoptables yet</p>
          <Button
            onClick={() => { resetForm(); setAddAdoptableOpen(true); }}
            className="transition-all duration-300 hover:scale-105 hover:shadow-lg hover:bg-primary/90"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Your First Adoptable
          </Button>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {myAdoptables.map((adoptable, index) => (
            <Card
              // FIX: Unique Key check
              key={adoptable.id || adoptable.ID || adoptable._id || index}
              className="overflow-hidden"
            >
              <div className="relative aspect-square">
                <ImageWithFallback
                  src={getImageUrl(adoptable.images && adoptable.images.length > 0 ? adoptable.images[0] : null)}
                  alt={adoptable.name}
                  className="w-full h-full object-cover"
                />
                <Badge
                  className="absolute top-2 right-2"
                  variant={
                    adoptable.status === 'adopted'
                      ? 'default'
                      : adoptable.status === 'pending'
                        ? 'secondary'
                        : 'outline'
                  }
                >
                  {adoptable.status || 'Available'}
                </Badge>
              </div>

              <CardContent className="pt-4">
                <h3 className="text-lg font-bold">{adoptable.name}</h3>
                <p className="text-sm text-gray-600">
                  {adoptable.type} ({adoptable.breed}) • {adoptable.age} years
                </p>
              </CardContent>

              <CardFooter className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => navigate(`/adoptable/${adoptable.id || adoptable.ID || adoptable._id}`)}
                  className="flex-1"
                >
                  <Eye className="h-4 w-4 mr-1" />
                  View
                </Button>

                <Button size="sm" variant="outline" onClick={() => openEditDialog(adoptable)}>
                  <Edit className="h-4 w-4" />
                </Button>

                <Button size="sm" variant="outline" onClick={() => setDeletingAdoptableId(adoptable.id || adoptable.ID || adoptable._id)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}

      {/* ADD / EDIT DIALOG */}
      <Dialog open={addAdoptableOpen} onOpenChange={setAddAdoptableOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>{editingAdoptable ? 'Edit Adoptable' : 'Add New Adoptable'}</DialogTitle>
            <DialogDescription>
              {editingAdoptable
                ? "Update the details of your adoptable below."
                : "Enter the details for the new adoptable you want to list."}
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            {/* NEW: Image Upload Field */}
            <div className="grid gap-2">
              <Label htmlFor="images">Pet Images</Label>
              <div className="flex items-center gap-4">
                <Input
                  id="images"
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={handleFileChange}
                  className="cursor-pointer"
                />
                {imagePreview && (
                  <div className="h-10 w-10 rounded overflow-hidden border">
                    <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
                  </div>
                )}
              </div>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="name">Name</Label>
              <Input id="name" name="name" value={adoptableForm.name} onChange={handleFormChange} placeholder="Name" />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="type">Type</Label>
                <select
                  id="type"
                  name="type"
                  value={adoptableForm.type}
                  onChange={handleFormChange}
                  className={selectStyle}
                >
                  {Object.keys(PET_DATA).map((type) => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
              </div>

              <div className="grid gap-2">
                <Label htmlFor="breed">Breed</Label>
                <select
                  id="breed"
                  name="breed"
                  value={adoptableForm.breed}
                  onChange={handleFormChange}
                  className={selectStyle}
                  disabled={!adoptableForm.type}
                >
                  <option value="" disabled>Select Breed</option>
                  {PET_DATA[adoptableForm.type]?.map((breed) => (
                    <option key={breed} value={breed}>{breed}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="age">Age (years)</Label>
                <Input id="age" name="age" type="number" min="0" value={adoptableForm.age} onChange={handleFormChange} />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="weight">Weight (kg)</Label>
                <Input id="weight" name="weight" type="number" min="0" value={adoptableForm.weight} onChange={handleFormChange} />
              </div>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="address">Address</Label>
              <Input id="address" name="address" value={adoptableForm.address} onChange={handleFormChange} />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="description">Description</Label>
              <Textarea id="description" name="description" value={adoptableForm.description} onChange={handleFormChange} />
            </div>
          </div>
          <DialogFooter>
            <Button onClick={editingAdoptable ? handleUpdateAdoptable : handleAddAdoptable}>
              {editingAdoptable ? 'Save Changes' : 'Add Adoptable'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={deletingAdoptableId !== null} onOpenChange={() => setDeletingAdoptableId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove Adoptable Listing</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to remove this adoptable from your listings? This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => deletingAdoptableId && handleDeleteAdoptable(deletingAdoptableId)}>
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};