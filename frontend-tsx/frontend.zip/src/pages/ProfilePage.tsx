import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";

import { Badge } from "../components/ui/badge";

import { User, Mail, Briefcase, Home, Clock, PawPrint } from "lucide-react";
import { toast } from "sonner";

export default function ProfilePage() {
  const navigate = useNavigate();

  // ---------------------------------------------------------
  // STATE
  // ---------------------------------------------------------
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [user, setUser] = useState<any>(null);

  const [formData, setFormData] = useState({
    name: "",
    occupation: "",
    address: "",
    availableTime: "",
    pastExperience: "",
  });

  // ---------------------------------------------------------
  // FETCH USER DETAILS FROM BACKEND
  // ---------------------------------------------------------
  useEffect(() => {
    const fetchUser = async () => {
      try {
        const jwtToken = localStorage.getItem("token"); // <-- GET TOKEN HERE

        const res = await fetch("http://localhost:4000/api/users/me",
        { headers: { Authorization: `Bearer ${jwtToken}` },
        // credentials: "include",
        });

        if (!res.ok) throw new Error("Failed to fetch profile");

        const data = await res.json();
        console.log(data);
        setUser(data);

        setFormData({
          name: data.name || "",
          occupation: data.occupation || "",
          address: data.address || "",
          availableTime: data.availableTime || "",
          pastExperience: data.pastExperience || "",
        });
      } catch (err: any) {
        toast.error(err.message || "Could not load profile");
      } finally {
        setLoading(false);
      }
    };

    fetchUser();
  }, []);

  // ---------------------------------------------------------
  // HANDLE UPDATE PROFILE (PUT REQUEST)
  // ---------------------------------------------------------
  const saveChanges = async () => {
    try {
      const jwtToken = localStorage.getItem("token"); // <-- GET TOKEN HERE
        // headers: { Authorization: `Bearer ${jwtToken}` },

      const res = await fetch("http://localhost:4000/api/users/me", {
        method: "PUT",
        headers: { 
          "Content-Type": "application/json",
          Authorization: `Bearer ${jwtToken}`
        },
        // credentials: "include",
        body: JSON.stringify(formData),
      });

      const data = await res.json();
      // console.log(data)

      if (!res.ok) {
        toast.error(data.message || "Update failed");
        return;
      }

      toast.success("Profile updated!");

      setUser(data);
      setIsEditing(false);
    } catch (err) {
      toast.error("Something went wrong");
    }
  };

  // ---------------------------------------------------------
  // LOADING SCREEN
  // ---------------------------------------------------------
  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <p>Loading profile...</p>
      </div>
    );
  }

  // ---------------------------------------------------------
  // BLOCK IF USER NOT FOUND
  // ---------------------------------------------------------
  if (!user) {
    return (
      <div className="container mx-auto px-4 py-8">
        <p>Unable to load profile. Please log in.</p>
        <Button className="mt-4" onClick={() => navigate("/login")}>
          Go to Login
        </Button>
      </div>
    );
  }

  // ---------------------------------------------------------
  // PAGE UI
  // ---------------------------------------------------------
  return (
    <div className="container mx-auto px-4 py-8 max-w-3xl">
      <div className="mb-8">
        <h1 className="text-3xl mb-2">My Profile</h1>
        <p className="text-gray-600">Manage your account information</p>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Account Information</CardTitle>
              <CardDescription>Your personal details</CardDescription>
            </div>
            <Badge variant={user.role === "parent" ? "default" : "secondary"}>
              {user.role === "parent" ? "Pet Parent" : "Adopter"}
            </Badge>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Name */}
          <div className="flex items-start gap-3">
            <User className="h-5 w-5 text-gray-400 mt-1" />
            <div className="flex-1">
              <Label>Full Name</Label>
              {isEditing ? (
                <Input
                  value={formData.name}
                  onChange={(e) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                />
              ) : (
                <p>{user.name}</p>
              )}
            </div>
          </div>

          {/* Email */}
          <div className="flex items-start gap-3">
            <Mail className="h-5 w-5 text-gray-400 mt-1" />
            <div className="flex-1">
              <Label>Email</Label>
              <p>{user.email}</p>
              <p className="text-xs text-gray-500">Email cannot be changed</p>
            </div>
          </div>

          {/* ADOPTER FIELDS */}
          {user.role === "adopter" && (
            <>
              <div className="border-t pt-6 space-y-4">
                {/* Occupation */}
                <div className="flex items-start gap-3">
                  <Briefcase className="h-5 w-5 text-gray-400 mt-1" />
                  <div className="flex-1">
                    <Label>Occupation</Label>
                    {isEditing ? (
                      <Input
                        value={formData.occupation}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            occupation: e.target.value,
                          })
                        }
                      />
                    ) : (
                      <p>{user.occupation || "Not provided"}</p>
                    )}
                  </div>
                </div>

                {/* Address */}
                <div className="flex items-start gap-3">
                  <Home className="h-5 w-5 text-gray-400 mt-1" />
                  <div className="flex-1">
                    <Label>Address</Label>
                    {isEditing ? (
                      <Input
                        value={formData.address}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            address: e.target.value,
                          })
                        }
                      />
                    ) : (
                      <p>{user.address || "Not provided"}</p>
                    )}
                  </div>
                </div>

                {/* Available Time */}
                <div className="flex items-start gap-3">
                  <Clock className="h-5 w-5 text-gray-400 mt-1" />
                  <div className="flex-1">
                    <Label>Available Time</Label>
                    {isEditing ? (
                      <Input
                        value={formData.availableTime}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            availableTime: e.target.value,
                          })
                        }
                      />
                    ) : (
                      <p>{user.availableTime || "Not provided"}</p>
                    )}
                  </div>
                </div>

                {/* Past Experience */}
                <div className="flex items-start gap-3">
                  <PawPrint className="h-5 w-5 text-gray-400 mt-1" />
                  <div className="flex-1">
                    <Label>Past Experience</Label>
                    {isEditing ? (
                      <Textarea
                        rows={3}
                        value={formData.pastExperience}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            pastExperience: e.target.value,
                          })
                        }
                      />
                    ) : (
                      <p>{user.pastExperience || "Not provided"}</p>
                    )}
                  </div>
                </div>
              </div>
            </>
          )}

          {/* Buttons */}
          <div className="flex gap-2 pt-4">
            {isEditing ? (
              <>
                <Button onClick={saveChanges} className="flex-1">
                  Save Changes
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsEditing(false);
                    setFormData({
                      name: user.name,
                      occupation: user.occupation || "",
                      address: user.address || "",
                      availableTime: user.availableTime || "",
                      pastExperience: user.pastExperience || "",
                    });
                  }}
                >
                  Cancel
                </Button>
              </>
            ) : (
              <Button onClick={() => setIsEditing(true)} className="flex-1">
                Edit Profile
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
